const fs = require('fs'); console.log(fs.existsSync('.env') ? 'Exists' : 'Missing');
