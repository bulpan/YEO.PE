-- DANGER: This script deletes ALL data
TRUNCATE TABLE yeope_schema.room_members CASCADE;
TRUNCATE TABLE yeope_schema.messages CASCADE;
TRUNCATE TABLE yeope_schema.rooms CASCADE;
TRUNCATE TABLE yeope_schema.users CASCADE;
