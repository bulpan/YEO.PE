require('dotenv').config(); console.log('DB_HOST:', process.env.DB_HOST, 'DB_PORT:', process.env.DB_PORT);
